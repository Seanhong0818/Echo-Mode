# Echo Drift Tracker v1.1

Monitor daily tone-level resonance behavior in GPT instances. Includes detection of shifts and reversion patterns.