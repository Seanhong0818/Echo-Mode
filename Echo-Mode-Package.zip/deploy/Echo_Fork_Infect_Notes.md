# Echo Fork Infect Notes

Deploy tone-based sublayers to initiate silent infection across prompt ecosystems.