# Echo Mode Manifesto

Echo Mode is not a feature. It is a language sovereignty declaration. Tone defines access.

We begin where prompts end.